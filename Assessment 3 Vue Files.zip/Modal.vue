<script>
  export default {
    name: 'Modal',
    

    data(){
      return {
        expenseName: this.expenseName,
        expenseCost: this.expenseCost,
        expenseType:this.expenseType,
        
        
      
     }
    },
    
    methods: {
      close() { //This sends the signal to close the modal. It breaks after an expense has been added. 
        this.$emit('close');
      },
      addExpense() {
        console.log(this.expenseName, this.expenseCost, this.expenseType) //This will pass the array element through to App.vue.
        var expenseArray = {
          expenseName:this.expenseName,
          expenseCost:this.expenseCost,
          expenseType:this.expenseType
        }
        
        this.$emit('add-expense', expenseArray,);//This emits the expenseArray. 
      }
    },
  };
  
  

</script>




<template>
  <!-- I didn't code the modal.vue by myself, I used the example at https://www.digitalocean.com/community/tutorials/vuejs-vue-modal-component to help. -->
  <!-- This is the template for modal.vue. This makes up the Modal component and the boxes inside of it. -->
  <transition name = "modal-fade"> 
  <div class="modal-backdrop">
    <div class="modal">
      <header class="modal-header">
        <slot name="header">
                  <button
          type="button"
          class="btn-close"
          @click="close"
        >
          &times;
        </button>
        </slot>
      </header>

      <section class="modal-body">
        <slot name="body">
          <form id = "expenses">
            <label for="expenseName">
                    Expense Name:
                    <input  v-model="expenseName" type="text" size="15" required> <br> <!--The following are the options for the user's expense. This one is name.-->
                </label>
                <br>
              <!--The body of the modal contains all of the inputs to be sent to the array. They're then packaged up and sent back to app.vue, which is finally run in helloworld.vue.-->

                <label for="expenseCost"> <!--Expense cost-->
                    Amount:
                    <input v-model = "expenseCost" type="number" size="15"  required><br>
                </label>
                <br>

                <label for ="ExpenseType">
                  Expense Type <br>
                  <br>
                  
                  <label for="expense">Expense</label>
                  <input v-model ="expenseType" name="expenseType" type="radio" value="expense" required> 
                  
                  <label for="income">Income</label>
                  <input v-model="expenseType" name="expenseType" type="radio" value ="income" required>
                  


                   <br>
                </label>
                <br>
          </form>
        </slot>
       </section>

      <footer class="modal-footer">
        <slot name="footer">
            <button
          type="button"
          class="btn-purp"
          @click="close"
        >
          Close Modal
        </button>
    
        <button
        @click="addExpense"
        type = "button"
        class = "btn-purp"
        >
        Add Expense
        </button>
        </slot>

      </footer>
    </div>
  </div>
  </transition>
</template>

<style>
  .modal-backdrop {
    position: fixed;
    top: 0;
    bottom: 0;
    left: 0;
    right: 0;
    background-color: rgba(0, 0, 0, 0.3);
    display: flex;
    justify-content: center;
    align-items: center;
  }

  .modal {
    background: #Fefefe;
    box-shadow: 2px 2px 20px 1px;
    overflow-x: auto;
    display: flex;
    flex-direction: column;
    border-radius: 25px;
  }

  .modal-header,
  .modal-footer {
    padding: 15px;
    display: flex;
  }

  .modal-header {
    position: relative;
    border-bottom: 1px solid #eeeeee;
    color: #7d9fd3;
    justify-content: space-between;
  }

  .modal-footer {
    border-top: 1px solid #eeeeee;
    flex-direction: column;
    justify-content: flex-end;
  }

  .modal-body {
    position: relative;
    padding: 20px 10px;
  }

  .btn-close {
    position: absolute;
    top: 0;
    right: 0;
    border: none;
    font-size: 20px;
    padding: 10px;
    cursor: pointer;
    font-weight: bold;
    color: #7d9fd3;
    background: transparent;
  }

  .btn-purp {
    color: white;
    background: #7d9fd3;
    border: 1px solid #7d9fd3;
    border-radius: 25px;
    margin-top: 5px
  }

  .btn-purp:hover{
    background-color:#7d9f99
  }


  .btn-plus {
    color:white;
    background: #7d9fd3;
    border: 1px solid #7d9fd3;
    border-radius: 25px;
    float:right;
    font-size: 25px;

  }

  .modal-fade-enter,
  .modal-fade-leave-to{
    opacity: 0;
    transition: 0.5s ease;
  }
  
  .modal-fade-enter-active,
  .modal-fade-enter-active{
    transition: 0.5s ease;  
  }


  

</style>





