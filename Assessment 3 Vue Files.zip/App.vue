<template>
  <div id="app">
    <div class="navbar">
        <p>Moneybags</p>
        <a href="#">Login</a>
        <a href="#">About Us</a>
        <a href="faq.html">FAQ</a>  
    </div>

<!--This is the code that brings up the modal. -->
     <button  
      type="button"
      class="plus"
      @click="showModal" 
    >
      +
    </button>

    <Modal
      v-show="isModalVisible"
      @add-expense="addExpense"
      @close="closeModal" 
    />
  <!-- The modal is the custom element we created earlier. This contains the closeModal event and the add-expense events, which perform the related functions (explained below) -->
<div class="namePlate">Joseph Smith's expenses</div>


  <table id="expensesTable">
        
        <tr>
            <th>Name</th>
            <th>Category</th>
            <th>
                <pre>  $  </pre>
            </th>
        </tr>
            
        <tr v-for="(expense, index) in expenses" , v-bind:key="index">
            <td>{{expense.expenseName}}</td>
            <td>{{expense.expenseType}}</td>
            <td>{{expense.expenseCost}}</td> <!--All of these elements should update with the array that is defined below, except they don't. I think it's an edge case.-->
        



        </tr>
        <tr>
            <td></td>
            <td></td>
            <td>
                <div class="subtotal" id ="subtotal">{{this.subtotal}} </div>
            </td>
            <td></td>
        </tr>
 </table>
  </div>
</template>

<script>
  import Modal from './components/Modal.vue';


  export default {
    name: 'App',
    components: { //Vue component "modal" has been imported here. I didn't need to use props because the child talks to the parent, not the other way around. Props are used Parent-to-child. 
      Modal,
    },
    data() {
      return {
        isModalVisible: false,
        expenses:[],
        expenseName: "",
        expenseCost: "",
        expenseType: "",
        subtotal: 0, //Declarations of variables. I have to initialize them here. 
      };
    },
    methods: {
      showModal() {
        this.isModalVisible = true;
      },
      closeModal() {
        this.isModalVisible = false;
    },
     addExpense(expense) {
      
      this.expenses.push(expense)
      console.log(this.expenses) //Logging to console to prove that my code is coherent and actually works, however the DOM elements don't update.
      
        //This if statement works by checking if expense.expenseCost is income or expense. If it's an income, it adds, otherwise it subtracts. 
        if (expense.expenseType == "income")
        {
         this.subtotal = this.subtotal + parseInt(expense.expenseCost) 
          console.log(this.subtotal)  
        } 
        else{
         this.subtotal = this.subtotal - parseInt(expense.expenseCost)
          console.log(this.subtotal)
        }
      
      
      },
  }
        
  }
</script>

<style>
  body{
    font-family: Arial, Helvetica, sans-serif;
  }


  .navbar { /*This styles the navigation bar*/
    overflow: hidden; /*Ensures that if the navigation bar overflow is clipped.*/
    background-color: #7d9fd3;
}

.navbar a { /*This styles the navigation bar links*/
    float: left; /*Allows text and other inline elements to be wrapped around it, denotes a starting point (the left of the page)*/
    display: block; /*Displays the type of box/boxes generated for an element. float specifies how a box should be floated*/
    color: white;
    text-align: center; /*Centers the text in the link.*/
    padding: 17px 20px; /*Determines the thickness of the padding area*/
    text-decoration: none;
}

.navbar a:hover { /*This specifies an event that occurs when the link is hovered over*/
    background-color: #59687f;
}

.footer {
    background-color: #c4c4c4; /*Styling for my footer*/
    padding: 10px;
    color:black;
    font-size: 8pt;
}

.navbar p {
    float: left; /*The same as the navbar.a, but for the paragraph which displays "moneybags" in the navbar*/
    display: block; 
    color: white;
    text-align: center;
    padding: 0px 15px; 
    text-decoration: none;
}
#expensesTable { /*Controls the styling for the expenses table, the main component of the website. In this case, it's filled with dummy values and can't be interacted with, but this shows how the webpage would be set up using css. */
    
    font-family: Arial;
    border-collapse: collapse;
    width: 50%;
    margin-left: auto;
    margin-right: auto;
    padding-top: 100px;
    padding-bottom: 20px;
    text-align: center;
    background-color: #c4c4c4;
    border-radius: 15px;
    font-size: 10pt;
    margin-bottom: 100px;
    margin-top:65px;
    
}

#expensesTable tr:nth-child(even){
    background-color: #d8d8d8;
}

#expensesTable tr:last-child > td {
    border-bottom: none;
}

#expensesTable td{
    padding-bottom: 10px;
    padding-top: 10px;
}

*{ /*This is styling for all html elements that don't fall under specific tags, to ensure uniformity.*/
    box-sizing:border-box; /*This means that the box will work with any margins or padding */
    font-family: Arial;    /*We're using the Arial font because almost every system has it installed.*/
}

body{
    margin: 0px; 
    font-family: Arial;
}

.navbar { /*This styles the navigation bar*/
    overflow: hidden; /*Ensures that if the navigation bar overflow is clipped.*/
    background-color: #7d9fd3;
}

.navbar a { /*This styles the navigation bar links*/
    float: left; /*Allows text and other inline elements to be wrapped around it, denotes a starting point (the left of the page)*/
    display: block; /*Displays the type of box/boxes generated for an element. float specifies how a box should be floated*/
    color: white;
    text-align: center; /*Centers the text in the link.*/
    padding: 14px 16px; /*Determines the thickness of the padding area*/
    text-decoration: none;
}

.navbar a:hover { /*This specifies an event that occurs when the link is hovered over*/
    background-color: #59687f;
}

.footer {
    background-color: #c4c4c4; /*Styling for my footer*/
    padding: 10px;
    color:black;
    font-size: 8pt;
}

.navbar p {
    float: left; /*The same as the navbar.a, but for the paragraph which displays "moneybags" in the navbar*/
    display: block; 
    color: white;
    text-align: center;
    padding: 0px 15px; 
    text-decoration: none;
}

.article { /*This is the article class used by the the div in the faq.html. This gives the webpage a centered look, and means that it can be viewed on any device.*/
  float:inherit;
  width: 75%;
  margin-left: auto;
  margin-right: auto;
  text-align: center;
  background-color: #d8d8d8;
  border-radius: 25px;
  margin-top: 30px;
  margin-bottom:30px;
}

h2 { /*Styling for header two*/
    text-align: left;
    padding-left: 30px;
}

#main_page{ /*Styling for paragraphs using the "main_page* tag.*/
    text-align: left;
    padding-left: 30px;
    padding-bottom: 30px;
    margin-right: 55px;
}

h1 { /*Styling for heading 1*/
    padding-top: 30px;
}

.rectangle { /*This isn't being used yet but it will be called later on, in my other pages.*/
    height:300px;
    width: 75%;
    background-color: #d8d8d8;
    position: center;
    margin-left: auto; 
    margin-right: auto;
    border-radius: 25px; 
    padding-right: 300px;
    padding-top: 20px;
    padding-left: 15px;
}

#expensesTable { /*Controls the styling for the expenses table, the main component of the website. In this case, it's filled with dummy values and can't be interacted with, but this shows how the webpage would be set up using css. */
    
    font-family: Arial;
    border-collapse: collapse;
    width: 50%;
    margin-left: auto;
    margin-right: auto;
    padding-top: 100px;
    padding-bottom: 20px;
    text-align: center;
    background-color: #c4c4c4;
    border-radius: 15px;
    font-size: 10pt;
    
    margin:relative;
    
}

#expensesTable tr:nth-child(even){
    background-color: #d8d8d8;
}

#expensesTable tr:last-child > td {
    border-bottom: none;
}

#expensesTable td{
    padding-bottom: 10px;
    padding-top: 10px;
}


.namePlate{ /*The biggest challenge I am facing at the moment is using float and flexbox correctly, right now for the main webpage moving or changing aspects seems to move some components around. In phone view it's not too bad, but for some displays it might cause problems.*/
    float: left;
    width: 35%;     
    height: auto;
    background-color:#7d9fd3;
    border-radius: 25px;
    font-size: 28pt;
    font-weight: bold;
    margin-left: 26%;
    margin-bottom: 20px; /*Margins affect elements OUTSIDE of this element, padding affects text and content INSIDE this element. */
    color: white;
    text-align: center;
    margin-top: 40px;
}

.expense{  /*The two expense categories are shown below. In the final javascript iteration, this will be automatically assigned to the table row, but for now it is manually assigned.*/
    color:red;
}

.credit{
    color:green;
}

.plus{ /*Completely non functional at the moment, at the moment is pure proof of concept showing that buttons can be rounded and manipulated. Positioning this element was a pain, and I'm still trying to wrap my head around floats and blocks. */
    float:right;
    width: 75px;     
    height: auto;
    background-color:#7d9fd3;
    border-radius: 25px;
    font-size: 28pt;
    font-weight: bold;
    color: white;
    text-align: center;  
    margin-bottom: 10px;
    margin-right: 450px;
    position:sticky;
    border-color: #7d9fd3;
    border-width: 0px;
    margin-top: 40px;
    margin:relative;
}

.buttonHolder{
    float:right;
    padding-left: 10px;
}


.subtotal{  
    float: auto;
    width: 200px;
    height: 30px;
    background-color: #7d9fd3;
    border-radius: 25px;
    text-align: left;
    padding-top: 7px;
    padding-left: 20px;
    color:white;
}


#submit{
    width: 75px;     
    height: auto;
    background-color:#7d9fd3;
    border-radius: 25px;
    font-weight: bold;
    color: white;
    text-align: center;  
    margin-bottom: 10px;
    margin-right: 450px;
}




</style>


